(function () {
  "use strict";

  document.documentElement.classList.add("js");

  var navToggle = document.querySelector(".nav-toggle");
  var siteNav = document.querySelector(".site-nav");
  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      var isOpen = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
    });
  }

  var quote = document.getElementById("random-quote");
  var quoteSource = document.getElementById("quote-source");
  var quotes = [
    ["有些电影，过了很久还记得其中一个镜头。", "观影随记 · 本站撰写"],
    ["看完别急着关掉，也听听片尾的那首歌。", "观影随记 · 本站撰写"],
    ["今晚有空的话，挑一部一直想看的电影吧。", "观影随记 · 本站撰写"],
    ["同一部电影，隔几年再看，喜欢的地方也许会变。", "观影随记 · 本站撰写"]
  ];
  if (quote && quoteSource) {
    var selected = quotes[Math.floor(Math.random() * quotes.length)];
    quote.textContent = selected[0];
    quoteSource.textContent = "— " + selected[1];
  }

  var backToTop = document.querySelector(".back-to-top");
  if (backToTop) {
    window.addEventListener("scroll", function () {
      backToTop.classList.toggle("is-visible", window.scrollY > 420);
    }, { passive: true });
    backToTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
    });
  }
})();
